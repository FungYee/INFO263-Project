function queryByNameOrId(){
            $("#search_results").show();
            var fname=$("#fname").val();
            var lname=$("#lname").val();
            var id=$("#invoiceId").val();
            if ((typeof(fname)=="undefined"||fname=="")&&(typeof(lname)=="undefined"||lname=="")&&(typeof(id)=="undefined"||id==""))
            {
                alert("Please enter the name of customer or the Invoice ID");
                return;
            }
            if (((typeof(lname)=="undefined"||lname=="")||(typeof(fname)=="undefined"||fname==""))&&(typeof(id)=="undefined"||id==""))
            {
                alert("Please enter the whole name of customer");
                return;
            }
            $.post("./request/queryByNameOrId.php", {fname : fname,lname : lname,id:id}, function(data){
                //Check whether the result of query is null. If it is, data returned by queryByNameOrId.php only contains the header of the table in length of 800.
                if (data.length>800){
                    $("#search_results").html(data);
                    var count=$("#count").val();
                    for(var a=0;a<count;a++){
                        //Calculate GST and total price and show them
                        var quantity=parseFloat($("#quantity_"+a).text());
                        var unit_price=parseFloat($("#unit_price_"+a).text());
                        var gst=0.15*quantity*unit_price;
                        gst=(gst+"");
                        gst=gst.substring(0,gst.indexOf(".")+4); //Use substring to take the 3 digit after decimal point.
                        $("#gst_"+a).html(gst);
                        var total_price=1.15*quantity*unit_price;
                        total_price=(total_price+"");
                        total_price=total_price.substring(0,total_price.indexOf(".")+4);
                        $("#total_price_"+a).html(total_price);
                    }

                }
                else{
                    $("#search_results").html("<p class=\"text-warning text-center\">THERE IS NO SUCH INVOICE IN OUR DATABASE</p>");
                }
            })

        }
        function queryByInvoiceId(i){
            //$("#myModal").show();
            var invoiceId=$("#invoiceId_"+i).attr("invoiceId");

            $.ajax({
                type: 'POST',
                url: "./request/queryByInvoiceId.php",
                async:false,
                data: {invoiceId:invoiceId},
                dataType:"text",
                success:function(detail){
                    $("#detailview").html(detail);
                    $("#myModalLabel").html("Details of Invoice "+invoiceId);
                }
            })
        }