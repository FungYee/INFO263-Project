<?php
// include("config/config.php") returns an error, need to use absolute path of the config.php in the server.
$pathOfThis=realpath("./");
$path=substr($pathOfThis,0,strlen($pathOfThis)-7);
include($path."config/config.php");

$invoiceId = $_POST["invoiceId"] ;

/*establish connection con to query table targetvalue*/
$con = mysqli_connect($serverName,$username,$password);
if (!$con)
{
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,$dbName);
// choose utf-8 code
mysqli_set_charset($con, "utf8");

$targetValueQuerySql="SELECT * FROM mydb.targetvalue";
$targetValueResult = mysqli_query($con,$targetValueQuerySql);

while ($targetValue = mysqli_fetch_array($targetValueResult)){
    $rear_axle_camber_left_right_target= $targetValue['rear_axle_camber_left_right_target'];
  $rear_axle_camber_cross_target= $targetValue['rear_axle_camber_cross_target'];
  $rear_axle_toe_left_right_target= $targetValue['rear_axle_toe_left_right_target'];
  $rear_axle_toe_total_target= $targetValue['rear_axle_toe_total_target'];
  $rear_axle_geometrical_driving_axis_target= $targetValue['rear_axle_geometrical_driving_axis_target'];
  $front_axle_camber_left_right_target= $targetValue['front_axle_camber_left_right_target'];
  $front_axle_camber_cross_target= $targetValue['front_axle_camber_cross_target'];
  $front_axle_caster_left_right_target= $targetValue['front_axle_caster_left_right_target'];
  $front_axle_caster_cross_target= $targetValue['rear_axle_camber_left_right_target'];
  $front_axle_sai_left_right_target= $targetValue['front_axle_sai_left_right_target'];
  $front_axle_sai_cross_target= $targetValue['front_axle_sai_cross_target'];
  $front_axle_track_differential_angle_left_right_target= $targetValue['front_axle_track_differential_angle_left_right_target'];
  $front_axle_toe_left_right_target= $targetValue['front_axle_toe_left_right_target'];
  $front_axle_toe_total_target= $targetValue['front_axle_toe_total_target'];
  $front_axle_setback_target= $targetValue['front_axle_setback_target'];
  $front_axle_max_steering_lock_left_steer_left_target= $targetValue['front_axle_max_steering_lock_left_steer_left_target'];
  $front_axle_max_steering_lock_left_steer_right_target= $targetValue['front_axle_max_steering_lock_left_steer_right_target'];
  $front_axle_max_steering_lock_right_steer_left_target= $targetValue['front_axle_max_steering_lock_right_steer_left_target'];
  $front_axle_max_steering_lock_right_steer_right_target= $targetValue['front_axle_max_steering_lock_right_steer_right_target'];
}

mysqli_close($con);
/*establish connection con1 to query invoice details*/
$con1 = mysqli_connect($serverName,$username,$password);
if (!$con1)
{
    die('Could not connect: ' . mysqli_error($con1));
}
mysqli_select_db($con1,$dbName);
// choose utf-8 code
mysqli_set_charset($con1, "utf8");

$sql="SELECT g.*,h.branch_gst_registration,h.branch_phone,h.branch_email,h.branch_fax,h.branch_email,h.branch_name,h.branch_address FROM 
(select e.*,f.branch_id,f.rear_axle_camber_left_before,f.rear_axle_camber_left_actual,f.rear_axle_camber_right_before,f.rear_axle_camber_right_actual,f.rear_axle_camber_cross_before,f.rear_axle_camber_cross_actual,f.rear_axle_toe_left_before,f.rear_axle_toe_left_actual,f.rear_axle_toe_right_before,f.rear_axle_toe_right_actual,f.rear_axle_toe_total_before,f.rear_axle_toe_total_actual,f.rear_axle_geometrical_driving_axis_before,f.rear_axle_geometrical_driving_axis_actual,f.front_axle_camber_left_before,f.front_axle_camber_left_actual,f.front_axle_camber_right_before,f.front_axle_camber_right_actual,f.front_axle_camber_cross_before,f.front_axle_camber_cross_actual,f.front_axle_caster_left_before,f.front_axle_caster_left_actual,f.front_axle_caster_right_before,f.front_axle_caster_right_actual,f.front_axle_caster_cross_before,f.front_axle_caster_cross_actual,f.front_axle_SAI_left_before,f.front_axle_SAI_left_actual,f.front_axle_SAI_right_before,f.front_axle_SAI_right_actual,f.front_axle_SAI_cross_before,f.front_axle_SAI_cross_actual,f.front_axle_track_differential_angle_left_before,f.front_axle_track_differential_angle_left_actual,f.front_axle_track_differential_angle_right_before,f.front_axle_track_differential_angle_right_actual,f.front_axle_toe_left_before,f.front_axle_toe_left_actual,f.front_axle_toe_right_before,f.front_axle_toe_right_actual,f.front_axle_toe_total_before,f.front_axle_toe_total_actual,f.front_axle_setback_before,f.front_axle_setback_actual,f.front_axle_max_steering_lock_left_steer_left_before,f.front_axle_max_steering_lock_left_steer_left_actual,f.front_axle_max_steering_lock_left_steer_right_before,f.front_axle_max_steering_lock_left_steer_right_actual,f.front_axle_max_steering_lock_right_steer_left_before,f.front_axle_max_steering_lock_right_steer_left_actual,f.front_axle_max_steering_lock_right_steer_right_before,f.front_axle_max_steering_lock_right_steer_right_actual from 
(select c.*,d.vehicle_id,d.vehicle_chassis,d.vehicle_registration,d.vehicle_make,d.vehicle_model,d.vehicle_body_type,d.vehicle_year from 
(select * from 
(select * FROM mydb.invoice where invoice_id = '".$invoiceId."') AS a LEFT JOIN mydb.owner as b on a.customer_id=b.owner_id ) 
as c LEFT JOIN mydb.vehicle d on c.owner_id=d.owner_id) AS e LEFT JOIN mydb.inspection as f on e.vehicle_id=f.vehicle_id) 
AS g LEFT JOIN mydb.branch as h on g.branch_id=h.branch_id";

$result = mysqli_query($con1,$sql);


    while ($row = mysqli_fetch_array($result)) {
        echo "<h1 class='text-center' ><strong>TYRES2GO</strong></h1>
                   <p class='text-center'><small>25 Opawa Rd Ph:033745034                        13 Stone St Ph:033277140</small></p>
                   <h2 class='text-center' >Branch Information</h2>
                   <div class=\"container\">
                   <div class=\"row align-items-center\">
                           <div class=\"col-2 col-md-3 \" ><p ><strong>" . $row['branch_name'] . "</strong></p></div>
                           <div class=\"col-9 col-md-9 \" ><p>" . $row['branch_address'] . "</p></div>
                   </div>                      
                   <div class=\"row\">
                           <div class=\"col-7 col-md-6 \"><p><strong>GST Registration No.:</strong></p></div>
                           <div class=\"col-4 col-md-6 \"><p>" . $row['branch_gst_registration'] . "</p></div>
                   </div>           
                   <div class=\"row\">   
                           <div class=\"col-6 col-md-6\" ><p><strong>Phone: </strong>" . $row['branch_phone'] . "</p></div>
                           <div class=\"col-6 col-md-6\" ><p><strong>Fax: </strong>" . $row['branch_fax'] . "</p></div>
                   </div>           
                   <div class=\"row\">   
                           <div class=\"col-2 col-md-3\" ><p><strong>Email: </strong></p></div>
                           <div class=\"col-9 col-md-9 \" ><p>" . $row['branch_email'] . "</p></div>
                   </div>           
                   <div class=\"row\">   
                           <div class=\"col-2 col-md-3\"><p><strong>Website: </strong></p></div>
                           <div class=\"col-9 col-md-9 \" ><p>tyres2go.net.nz</p></div>
                   </div> 
                   </div>
                   <h2 class='text-center' >Customer Information</h2>
                   <div class=\"container\">
                   <div class=\"row\">
                  
                           <div class=\"col-4 col-md-4\"><p><strong>BILL TO: </strong><br>" . $row['owner_fname'] . " " . $row['owner_lname'] . "</p><br><p><strong>Tel: </strong><br>" . $row['owner_phone'] . "</p></div>
      
                           <div class=\"col-8 col-md-8\">
                           <div class=\"row\">
                           <p class=\"col-8 col-md-5\"><strong>FOR: </strong></p>
                           </div>
                           
                           <div class=\"row\">
                           <p class=\"col-5 col-md-5\"><strong>Model: </strong></p>" . $row['vehicle_make'] . " " . $row['vehicle_model'] . "
                           </div>
                           
                           <div class=\"row\">
                           <p class=\"col-5 col-md-5\"><strong>Reg No.: </strong></p>" . $row['vehicle_registration'] . "</div>
                           <div class=\"row\">
                           <p class=\"col-5 col-md-5\"> <strong>Chassis: </strong></p>" . $row['vehicle_chassis'] . "</div>
                           <div class=\"row\">
                           <p class=\"col-3 col-md-5\"><strong>Vin: </strong></p>" . $row['vehicle_id'] . "</div>
                           <div class=\"row\">
                           <p class=\"col-6 col-md-5\"><strong>Body Type: </strong></p>" . $row['vehicle_body_type'] . "</div>
                           <div class=\"row\">
                           <p class=\"col-5 col-md-5\"><strong>Year: </strong></p>" . $row['vehicle_year'] . "</div>
                           </div>
       
                   </div> 
                   </div>
                   <h2 class='text-center' >Invoice Information</h2>
                   <div class=\"container\">
                   <div class=\"row\">
                           <div class=\"col-4 col-md-4\"><p><strong>Invoice NO.: </strong></p></div>
                           <div class=\"col-7 col-md-2\">" . $row['invoice_id'] . "</div>
                           <div class=\"col-4 col-md-3\" ><p><strong>Date: </strong></p></div>
                           <div class=\"col-7 col-md-3\" >" . $row['date'] . "</div>
                   </div>        
                   <div class=\"row\">
                           <div class=\"col-4 col-md-4\" ><p><strong>Due Date: </strong></p></div>
                           <div class=\"col-7 col-md-4\">" . $row['due_date'] . "</div>
                   </div>        
                   <div class=\"row\">        
                           <div class=\"col-4 col-md-4\" ><p><strong>Description: </strong></p></div>
                           <div class=\"col-7 col-md-8\">" . $row['description'] . "</div>
                   </div>        
                   <div class=\"row\">
                           <div class=\"col-4 col-md-4\" class='text-center'><p><strong>Quantity: </strong></p></div>
                           <div class=\"col-7 col-md-2\">" . $row['quantity'] . "</div>
                           <div class=\"col-4 col-md-3\" class='text-center'><p><strong>Unit Price: </strong></p></div>
                           <div class=\"col-7 col-md-3\">" . $row['unit_price'] . "</div>
                   </div> 
                   <div class=\"row\">
                           <div class=\"col-4 col-md-4\"><p><strong>Amount: </strong></p></div>
                           <div class=\"col-7 col-md-2\">" . (floatval($row['quantity']) * floatval($row['unit_price'])) . "</p></div>                     
                           <div class=\"col-4 col-md-3\" ><p><strong>GST: </strong></p></div>
                           <div class=\"col-7 col-md-3\" >" . (0.15 * floatval($row['quantity']) * floatval($row['unit_price'])) . "</div>
                   </div>        
                   <div class=\"row\">  
                           <div class=\"col-4 col-md-4\" class='text-center'><p><strong>Total: </strong></p></div>
                           <div class=\"col-7 col-md-2\" >" . (1.15 * floatval($row['quantity']) * floatval($row['unit_price'])) . "</div>
                   </div> 
                   </div>
                   <h2 class='text-center' >Inspection Information</h2>
                   <table class=\"table\">
                          <thead class=\"w-100\">
                                 <tr class=\"row mx-0\">
                                 <th class=\"col-4 text-center\"></th>
                                 <th class=\"col-2 text-center\">Before</th>
                                 <th class=\"col-4 text-center\">Target Data</th>
                                 <th class=\"col-2 text-center\">Actual</th>
                                 </tr>
                          </thead>
                          <tbody class=\"w-100\">
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Camber Left</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_camber_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Camber Right</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_camber_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Camber Cross</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_cross_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_camber_cross_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_camber_cross_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Toe Left</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_toe_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Toe Right</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_toe_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Toe Total</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_total_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_toe_total_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_toe_total_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Rear Axle Geometrical Driving Axis</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_geometrical_driving_axis_before'] . "</td>
                                  <td class=\"col-4 text-center\">$rear_axle_geometrical_driving_axis_target</td>
                                  <td class=\"col-2 text-center\">" . $row['rear_axle_geometrical_driving_axis_actual'] . "</td>
                                  </tr>
                                  
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Camber Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_camber_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Camber Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_camber_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Camber Cross</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_cross_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_camber_cross_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_camber_cross_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Caster Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_caster_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Caster Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_caster_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Caster Cross</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_cross_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_caster_cross_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_caster_cross_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle SAI Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_sai_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle SAI Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_sai_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle SAI Cross</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_cross_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_sai_cross_target/td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_SAI_cross_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Track Differential Angle Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_track_differential_angle_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_track_differential_angle_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_track_differential_angle_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Track Differential Angle Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_track_differential_angle_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_track_differential_angle_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_track_differential_angle_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Toe Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_toe_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_left_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Toe Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_toe_left_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Toe Total</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_total_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_toe_total_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_toe_total_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Setback</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_setback_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_setback_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_setback_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Max Steering Lock Left Steer Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_left_steer_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_max_steering_lock_left_steer_left_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_left_steer_left_actual'] . "</td>
                                  </tr>
                                   <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Max Steering Lock Left Steer Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_left_steer_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_max_steering_lock_left_steer_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_left_steer_right_actual'] . "</td>
                                  </tr>
                                  <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Max Steering Lock Right Steer Left</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_right_steer_left_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_max_steering_lock_right_steer_left_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_right_steer_left_actual'] . "</td>
                                  </tr>
                                   <tr class=\"row mx-0\">
                                  <td class=\"col-4 text-center\">Front Axle Max Steering Lock Right Steer Right</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_right_steer_right_before'] . "</td>
                                  <td class=\"col-4 text-center\">$front_axle_max_steering_lock_right_steer_right_target</td>
                                  <td class=\"col-2 text-center\">" . $row['front_axle_max_steering_lock_right_steer_right_actual'] . "</td>
                                  </tr>
                          </tbody>
                   </table>
    
    ";

    }



mysqli_close($con1);
?>