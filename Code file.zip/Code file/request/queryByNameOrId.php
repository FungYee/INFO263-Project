<?php
// include("config/config.php") returns an error, need to use absolute path of the "config.php" file in the server.
$pathOfThis=realpath("./");
$path=substr($pathOfThis,0,strlen($pathOfThis)-7);
include($path."config/config.php");


$fname = isset($_POST["fname"]) ? $_POST["fname"] : '';
$lname = isset($_POST["lname"]) ? $_POST["lname"] : '';
$id = isset($_POST["id"]) ? $_POST["id"] : '';

if((empty($fname)||($fname==""))&&(empty($lname)||($lname==""))&&(empty($id)||($id==""))) {
    echo 'Please input the whole name of customer or the invoice ID';
    exit;
}
if(((empty($fname)||($fname==""))||(empty($lname)||($lname=="")))&&(empty($id)||($id==""))) {
    echo 'Please input the whole name of customer';
    exit;
}
//Establish connection to the database
$con = mysqli_connect($serverName,$username,$password);
if (!$con)
{
    die('Could not connect: ' . mysqli_error($con));
}
// set db
mysqli_select_db($con,$dbName);
// choose utf-8 code
mysqli_set_charset($con, "utf8");

//Constructing SQL
$sql="select a.invoice_id,a.description,a.quantity,a.unit_price,a.date,a.due_date from mydb.invoice as a,mydb.owner as b where a.customer_id=b.owner_id "; //and b.owner_lname='".$lname."' and b.owner_fname='".$fname."'
if(!empty($fname)&&($fname!="")) $sql=$sql."and b.owner_fname='".$fname."' ";
if(!empty($lname)&&($lname!="")) $sql=$sql."and b.owner_lname='".$lname."' ";
if(!empty($id)&&($id!="")) $sql=$sql."and a.invoice_id like '%".$id."%'";
$result = mysqli_query($con,$sql);

$i=0;  // i is for tagging the elements of each row and counting the number of rows.

echo "<table class=\"table\">
<thead class=\"w-100\">
<tr class=\"row mx-0\">
<th class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\">Invoice ID</th>
<th class=\"col-3 text-center\" style=\"vertical-align: middle !important;text-align: center;\">Description</th>
<th class=\"col-1 text-center\" style=\"vertical-align: middle !important;text-align: center;\">QTY</th>
<th class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\">Unit Price</th>
<th class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\">GST</th>
<th class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\">Total</th>
</tr>
</thead>
";

//if $row is not null, write the table of query result into the response message.
while ($row=mysqli_fetch_array($result)) {

    echo "<tbody class=\"w-100\">
                <tr class=\"row mx-0\">
              ";

    echo "<td class=\"col-2 text-center\"  style=\"vertical-align: middle !important;text-align: center;\"><button class='detail' style='width:60px;height:20px;vertical-align:middle;text-align: center;' id='invoiceId_" . $i . "' data-toggle='modal' data-target='#myModal' invoiceId='" . $row['invoice_id'] . "' onclick='queryByInvoiceId(" . $i . ")'><p style='font-size:12px;'>".$row['invoice_id']."</p></button></td>";
    echo "<td class=\"col-3 text-center\" style=\"vertical-align: middle !important;text-align: center;\">" . $row['description'] . "</td>";
    echo "<td class=\"col-1 text-center\" style=\"vertical-align: middle !important;text-align: center;\" id='quantity_" . $i . "'>" . $row['quantity'] . "</td>";
    echo "<td class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\" id='unit_price_" . $i . "'>" . $row['unit_price'] . "</td>";
    //Leave GST column and total price column blank. Calculate them in JS program.
    echo "<td class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\" id='gst_" . $i . "'></td>";
    echo "<td class=\"col-2 text-center\" style=\"vertical-align: middle !important;text-align: center;\" id='total_price_" . $i . "'></td>";
    echo "</tr></tbody>";
    $i=$i+1;
}
echo "<input type='hidden' id='count' value='$i'></input></table>";

//close the connection of the database and release the resources.
mysqli_close($con);
?>