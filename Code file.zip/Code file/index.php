<?php
    print <<<EOT

<html>
<head>
    <title>TYRES2GO Invoice</title>
<!--Using relative path to load the local JQuery and Bootstrap library-->
    <script src="script/jquery-3.3.1.js" type="text/javascript"></script>
    <script src="script/bootstrap.min.js" type="text/javascript"></script>
    <script src="script/script.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <meta name="viewport" content="width=device-width">

    <script type='text/javascript'>
        $(document).ready(function() {
            $("#search_results").slideUp();
            $("#search_button").click(function (e) {
                e.preventDefault();
                queryByNameOrId();
            });
        })
    </script>

</head>

<body>
<div class="kopa-header-bottom ">
    <div class="logo-box pull-left">
         <!--Using the logo image of tyres2go.net.nz just for course project. If any IP issues concerned, the image needs to be changed.-->
         <a href="/"><img src="company_logo_1.jpg" alt="Tyres2Go" /></a>
    </div>
</div>
<h1 class="text-center">Invoice Inquiry</h1>

    <div class="container">
        <div class="row align-items-center">
        <label class="col-md-2 col-sm-3 col-5 text-center" for="fname">First Name:</label>
        <input class="col-md-2 col-sm-3 col-6" type="text" name="fname" id="fname" />
        <label class="col-md-2 col-sm-3 col-5 text-center" for="lname">Last Name:</label>
        <input class="col-md-2 col-sm-3 col-6" type="text" name="lname" id="lname" />
        <label class="col-md-2 col-sm-3 col-5 text-center" for="invoiceId">InvoiceId:</label>
        <input class="col-md-2 col-sm-3 col-6" type="text" name="invoiceId" id="invoiceId" />
        </div>
        <div class="row align-items-center">
        <input class="col-sm-2 col-6"type="button" value="search" id="search_button" style="display:block;margin:0 auto"></input>
        </div>
        <div id="search_results"></div>
    </div>
    <!-------------------------------Bootstrap window: view invoices of the details---------------------------------------------------->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Invoice Details</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" id="detailview">
                    <!--invoice details content shows here-->
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    <div id="footer">
        <p id="bank">Goods are sold as per "Conditions of Sale" in our Credit Application.Returns
            limited to a maximum of thirty days. If TYRES2GO agrees that tyres can be
            returned, Fitting , Balancing , Tyre Disposal and freight costs incurred will be
            deducted from the credit. Tyre returns and claims must be returned promptly.
            Return freight is the client's responsibility. E&OE. In addition to the above are stocking charge will
            apply.Competition (Racing) and Rally tyres carry NO warranty.<br><br>Bank Account Number<br>030830045680800</p>
    </div>
</body>
</html>

EOT;
?>
