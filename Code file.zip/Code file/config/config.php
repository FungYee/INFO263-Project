<?php
/**
 * Created by PhpStorm.
 * User: kki43
 * Date: 11/07/2018
 * Time: 2:54 PM
 */
    $serverName = "localhost";
    $port = "3306";
    $username = "root";
    $password = "";
    $dbName = "mydb";
?>
